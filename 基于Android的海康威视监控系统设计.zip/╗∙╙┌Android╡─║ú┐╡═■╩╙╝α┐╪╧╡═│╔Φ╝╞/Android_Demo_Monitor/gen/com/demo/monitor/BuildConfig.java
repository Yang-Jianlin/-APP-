/** Automatically generated file. DO NOT MODIFY */
package com.demo.monitor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}